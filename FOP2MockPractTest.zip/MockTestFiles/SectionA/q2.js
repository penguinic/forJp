/* 
	Section A
	Question 2
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/

// Function: statvalue 
// Higher Order Function

// TODO: Code here


// Test the higher order function 
// using the following data

/*
sum = [1, 2, 4, 3, 7, 9];
average = [1, 2, 4, 3, 7, 9];
median = [2, 4, 5, 7, 1, 8, 1];
mode = [2, 4, 6, 2, 2];
*/

// TODO: Code here