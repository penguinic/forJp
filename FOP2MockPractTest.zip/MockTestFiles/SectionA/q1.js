/* 
	Section A
	Question 1
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/

let gifts = [
	{
		id: 0,
		name: 'John',
		relation: 'Brother',
		gift: 'jersey',
		greeting: 'Runnin Christmas'
	},
	{
		id: 1,
		name: 'Candice',
		relation: 'Sister',
		gift: 'portable fan',
		greeting: 'Breeze Christmas'
	},
	{
		id: 2,
		name: 'Fat Daddy',
		relation: 'Father',
		gift: 'T-Shirt',
		greeting: 'Fitting Christmas'
	},
	{
		id: 3,
		name: 'Love Mommy',
		relation: 'Mother',
		gift: 'grinder',
		greeting: 'Delicious Christmas'
	},
	{
		id: 4,
		name: 'Christina',
		relation: 'Aunt',
		gift: 'Sling Bags',
		greeting: 'Joyous Christmas'
	},

];

function myGifts() {
	// TODO: Code here

	return {

		// TODO: Code here
	}
}

// Display all the greeting message.
// TODO: Code here
