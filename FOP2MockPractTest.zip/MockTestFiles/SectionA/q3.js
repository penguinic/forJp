/* 
	Section A
	Question 3
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/


// TODO: Q3a Code here


// Display the result of "p2380923"
// TODO: Q3b Code here


// Display all student result 
// TODO: Q3c Code here

