/* 
	Section B
	Question 1
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/

const readline = require("readline-sync");

// Import the dataVehicleInfo.js and dataVehicleType.js data
// TODO: Q3a Code here

// Display Option Menu 
// TODO: Code here
/*
1. All Vehicle Type;
2. Query Vehicle Type;
3. Total Number of Vehicle By Year;
4. Exit;
*/

// TODO: Code here for each option 
